<template>

    <main class="bg-neutral-50 dark:bg-neutral-900 min-h-screen">
        <Header :nav-items="[
            { label: 'Home', href: '/' },
            {
                label: 'Products', children: [
                    { label: 'Item 1', href: '/products/1' },
                    { label: 'Item 2', href: '/products/2' },
                ]
            },
        ]" user-name="Vinicius Cordeiro" @search="onSearch">
            <template v-slot:brand>
                VCNexus
            </template>
        </Header>

        <router-view />
    </main>
</template>

<script setup>
import Header from '@/components/Header/Header.vue';


</script>

<style></style>